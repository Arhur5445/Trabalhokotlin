package com.example.jornadaconquista

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.jornadaconquista.ui.theme.JornadaConquistaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JornadaConquistaTheme {
                // A surface container using the 'background' color from the theme
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    GameScreen()
                }
            }
        }
    }
}

@Composable
fun GameScreen() {
    val clicks = remember { mutableStateOf(0) }
    val maxClicks = remember { mutableStateOf((1..50).random()) }
    val currentImage = remember { mutableStateOf(R.drawable.image_initial) }
    val showRetryDialog = remember { mutableStateOf(false) }
    val showCongratulation = remember { mutableStateOf(false) }
    val hasAbandoned = remember { mutableStateOf(false) }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxSize()
    ) {
        when {
            showCongratulation.value -> {
                CongratulationScreen(
                    onPlayAgain = {
                        resetGame(clicks, maxClicks, currentImage)
                        showCongratulation.value = false
                        hasAbandoned.value = false
                    },
                    onExit = {
                        // Implement exit or return to home
                    }
                )
            }
            hasAbandoned.value -> {
                Image(
                    painter = painterResource(id = R.drawable.image_desistencia),
                    contentDescription = null,
                    modifier = Modifier.size(300.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = { resetGame(clicks, maxClicks, currentImage); hasAbandoned.value = false }) {
                    Text("Novo Jogo")
                }
            }
            showRetryDialog.value -> {
                AlertDialog(
                    onDismissRequest = { showRetryDialog.value = false },
                    title = { Text("Desistir") },
                    text = { Text("Deseja realmente desistir?") },
                    confirmButton = {
                        Button(onClick = {
                            hasAbandoned.value = true
                            showRetryDialog.value = false
                        }) {
                            Text("Sim")
                        }
                    },
                    dismissButton = {
                        Button(onClick = { showRetryDialog.value = false }) {
                            Text("Não")
                        }
                    }
                )
            }
            else -> {
                Image(
                    painter = painterResource(id = currentImage.value),
                    contentDescription = null,
                    modifier = Modifier
                        .size(300.dp)
                        .clickable {
                            clicks.value++
                            updateImage(clicks.value, maxClicks.value, currentImage, showCongratulation)
                        }
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(onClick = { showRetryDialog.value = true }) {
                    Text("Desistir")
                }
            }
        }
    }
}

private fun updateImage(
    clicks: Int,
    maxClicks: Int,
    currentImage: MutableState<Int>,
    showCongratulation: MutableState<Boolean>
) {
    val progress = clicks.toFloat() / maxClicks
    when {
        progress < 0.33 -> currentImage.value = R.drawable.image_initial
        progress < 0.66 -> currentImage.value = R.drawable.image_mediana
        progress < 1.0 -> currentImage.value = R.drawable.image_final
        else -> {
            currentImage.value = R.drawable.image_conquista
            showCongratulation.value = true
        }
    }
}

private fun resetGame(
    clicks: MutableState<Int>,
    maxClicks: MutableState<Int>,
    currentImage: MutableState<Int>
) {
    clicks.value = 0
    maxClicks.value = (1..50).random()
    currentImage.value = R.drawable.image_initial
}

@Composable
fun CongratulationScreen(onPlayAgain: () -> Unit, onExit: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxSize()
    ) {
        Text("Parabéns pela conquista!", style = MaterialTheme.typography.headlineLarge)
        Image(
            painter = painterResource(id = R.drawable.image_conquista),
            contentDescription = null,
            modifier = Modifier.size(300.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = onPlayAgain) {
            Text("Jogar Novamente")
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = onExit) {
            Text("Sair")
        }
    }
}
