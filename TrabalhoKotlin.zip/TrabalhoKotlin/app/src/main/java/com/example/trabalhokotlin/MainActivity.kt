package com.example.trabalhokotlin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.trabalhokotlin.ui.theme.TrabalhoKotlinTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TrabalhoKotlinTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    GameScreen()
                }
            }
        }
    }
}

class GameViewModel : ViewModel() {
    var clicks = mutableStateOf(0)
        private set
    var maxClicks = mutableStateOf((1..50).random())
        private set
    var currentImage = mutableStateOf(R.drawable.image_initial)
        private set
    var showRetryDialog = mutableStateOf(false)
        private set
    var showCongratulation = mutableStateOf(false)
        private set
    var hasAbandoned = mutableStateOf(false)
        private set

    fun updateClicks() {
        clicks.value++
        updateImage()
    }

    private fun updateImage() {
        val progress = clicks.value.toFloat() / maxClicks.value
        when {
            progress < 0.33 -> currentImage.value = R.drawable.image_initial
            progress < 0.66 -> currentImage.value = R.drawable.image_mediana
            progress < 1.0 -> currentImage.value = R.drawable.image_final
            else -> {
                currentImage.value = R.drawable.image_conquista
                showCongratulation.value = true
            }
        }
    }

    fun resetGame() {
        clicks.value = 0
        maxClicks.value = (1..50).random()
        currentImage.value = R.drawable.image_initial
        showCongratulation.value = false
        hasAbandoned.value = false
    }

    fun abandonGame() {
        hasAbandoned.value = true
        showRetryDialog.value = false
    }

    fun showRetryDialog() {
        showRetryDialog.value = true
    }

    fun hideRetryDialog() {
        showRetryDialog.value = false
    }
}

@Composable
fun GameScreen(gameViewModel: GameViewModel = viewModel()) {
    val clicks by gameViewModel.clicks
    val maxClicks by gameViewModel.maxClicks
    val currentImage by gameViewModel.currentImage
    val showRetryDialog by gameViewModel.showRetryDialog
    val showCongratulation by gameViewModel.showCongratulation
    val hasAbandoned by gameViewModel.hasAbandoned

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxSize()
    ) {
        when {
            showCongratulation -> {
                CongratulationScreen(
                    onPlayAgain = { gameViewModel.resetGame() },
                    onExit = { /* Implement exit or return to home */ }
                )
            }
            hasAbandoned -> {
                Image(
                    painter = painterResource(id = R.drawable.image_desistencia),
                    contentDescription = null,
                    modifier = Modifier.size(300.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))


                Text(
                    text = "Que pena, tente novamente!",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(16.dp)
                )

                Button(onClick = { gameViewModel.resetGame() }) {
                    Text("Novo Jogo")
                }
            }
            showRetryDialog -> {
                AlertDialog(
                    onDismissRequest = { gameViewModel.hideRetryDialog() },
                    title = { Text("Mudar de rota") },
                    text = { Text("Deseja realmente mudar de rota?") },
                    confirmButton = {
                        Button(onClick = { gameViewModel.abandonGame() }) {
                            Text("Sim")
                        }
                    },
                    dismissButton = {
                        Button(onClick = { gameViewModel.hideRetryDialog() }) {
                            Text("Não")
                        }
                    }
                )
            }
            else -> {
                Image(
                    painter = painterResource(id = currentImage),
                    contentDescription = null,
                    modifier = Modifier
                        .size(300.dp)
                        .clickable { gameViewModel.updateClicks() }
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(onClick = { gameViewModel.showRetryDialog() }) {
                    Text("Mudar rota")
                }
            }
        }
    }
}

@Composable
fun CongratulationScreen(onPlayAgain: () -> Unit, onExit: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxSize()
    ) {
        Text("Parabéns por chegar ao seu destino!", style = MaterialTheme.typography.headlineLarge)
        Image(
            painter = painterResource(id = R.drawable.image_conquista),
            contentDescription = null,
            modifier = Modifier.size(300.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = onPlayAgain) {
            Text("Jogar Novamente")
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = onExit) {
            Text("Sair")
        }
    }
}
